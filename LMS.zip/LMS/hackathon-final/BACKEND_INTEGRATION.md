# Backend Integration Guide

This document explains how to integrate the optional backend with the frontend for a full-featured LMS.

## 🏗️ Backend Architecture

### Technology Stack
- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB
- **ODM**: Mongoose
- **Authentication**: JWT
- **Password Security**: Bcrypt

### API Endpoints

#### Authentication
```
POST /api/auth/register    # User registration
POST /api/auth/login       # User login
GET  /api/auth/profile     # Get user profile
```

#### Courses
```
POST /api/courses          # Create course (faculty)
GET  /api/courses          # Get all courses
GET  /api/courses/:id      # Get specific course
PUT  /api/courses/:id      # Update course (faculty)
DELETE /api/courses/:id    # Delete course (faculty)
```

#### Enrollments
```
POST /api/enrollments             # Enroll in course (student)
GET  /api/enrollments/my-courses  # Student's courses (student)
GET  /api/enrollments/course/:id  # Course students (faculty)
```

#### Assignments
```
POST /api/assignments              # Create assignment (faculty)
GET  /api/assignments/course/:id   # Course assignments
GET  /api/assignments/:id          # Specific assignment
PUT  /api/assignments/:id          # Update assignment (faculty)
DELETE /api/assignments/:id        # Delete assignment (faculty)
```

#### Submissions
```
POST /api/submissions                  # Submit assignment (student)
GET  /api/submissions/my-submissions   # Student's submissions (student)
GET  /api/submissions/assignment/:id   # Assignment submissions (faculty)
PUT  /api/submissions/:id/grade        # Grade submission (faculty)
```

## 🔧 Integration Steps

### 1. Backend Setup
```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file
echo "PORT=5000
MONGODB_URI=mongodb://localhost:27017/lms
JWT_SECRET=your_jwt_secret_here" > .env

# Start the server
npm start
```

### 2. Frontend Configuration
Update the API base URL in each HTML file:
```javascript
// Change from:
const API_BASE_URL = 'http://localhost:5000/api';

// To your deployed backend URL:
const API_BASE_URL = 'https://your-backend.onrender.com/api';
```

### 3. MongoDB Setup
1. Install MongoDB locally or use MongoDB Atlas
2. Update the MONGODB_URI in .env
3. Ensure the database is accessible

## 🔐 Security Considerations

### Authentication Flow
1. User registers/logs in
2. Server returns JWT token
3. Frontend stores token in localStorage
4. Token included in Authorization header for protected requests

### Password Handling
- Passwords hashed with bcrypt (10 rounds)
- Never stored in plain text
- JWT tokens expire after 7 days

## 🔄 Data Models

### User
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  role: String (student|faculty)
}
```

### Course
```javascript
{
  title: String,
  description: String,
  duration: Number,
  video: String,
  faculty: ObjectId (ref: User)
}
```

### Enrollment
```javascript
{
  student: ObjectId (ref: User),
  course: ObjectId (ref: Course)
}
```

### Assignment
```javascript
{
  title: String,
  description: String,
  dueDate: Date,
  course: ObjectId (ref: Course),
  faculty: ObjectId (ref: User)
}
```

### Submission
```javascript
{
  assignment: ObjectId (ref: Assignment),
  student: ObjectId (ref: User),
  submissionText: String,
  grade: {
    score: Number,
    feedback: String,
    gradedBy: ObjectId (ref: User),
    gradedDate: Date
  }
}
```

## 🚀 Deployment Options

### Backend Deployment
1. **Render** (Recommended)
   - Free tier available
   - Easy MongoDB integration
   - Automatic deployments from GitHub

2. **Heroku**
   - Well-documented
   - Large community support
   - Free tier with limitations

3. **DigitalOcean App Platform**
   - Good performance
   - Competitive pricing
   - Easy scaling options

### Database Deployment
1. **MongoDB Atlas**
   - Official MongoDB cloud service
   - Free tier available
   - Global distribution
   - Built-in security features

## 📊 Environment Variables

Create a `.env` file in the backend directory:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/lms
JWT_SECRET=your_super_secret_jwt_key_here
NODE_ENV=production
```

## 🔌 API Integration in Frontend

### Example: User Login
```javascript
// Frontend JavaScript
fetch('http://localhost:5000/api/auth/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'password123'
  })
})
.then(response => response.json())
.then(data => {
  if (data.token) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    window.location.href = 'dashboard.html';
  }
});
```

### Example: Protected Route
```javascript
// Include token in requests
const token = localStorage.getItem('token');
fetch('http://localhost:5000/api/courses', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
})
.then(response => response.json())
.then(courses => {
  // Handle courses data
});
```

This backend integration provides a complete, production-ready LMS with persistent data storage, user authentication, and all the features required for the expert level implementation.