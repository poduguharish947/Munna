# EduLearn LMS - Learning Management System

A comprehensive Learning Management System with features for both students and faculty.

## 🏆 Project Implementation

This project implements all required user stories from basic to advanced levels:

### Basic Level ✅
- User Registration & Login
- Course Management (Teacher role)
- Course Viewing (Student role)

### Intermediate Level ✅
- Course Enrollment

### Advanced Level ✅
- Assignment Submission

### Expert Level ✅
- Grading System

## 🚀 Features

### For Students:
- User registration and authentication
- Browse available courses
- Enroll in courses
- View enrolled courses
- Submit assignments
- View grades and feedback

### For Faculty:
- User registration and authentication
- Create and manage courses
- View enrolled students
- Create assignments
- Grade student submissions
- View submission statistics

## 🛠️ Tech Stack

### Frontend (Client-side only):
- **HTML5, CSS3, JavaScript**
- **Bootstrap 5** for responsive design
- **localStorage** for data persistence

### Backend (Optional - Full Version):
- **Node.js** with Express.js
- **MongoDB** with Mongoose ODM
- **JWT** for authentication
- **Bcrypt.js** for password hashing

## 📁 File Structure

```
project/
├── index.html        # Landing page
├── login.html        # Authentication page
├── student.html      # Student dashboard
├── faculty.html      # Faculty dashboard
├── README.md         # This file
└── screenshots/      # Application screenshots
    ├── landing.png
    ├── login.png
    ├── faculty.png
    └── student.png
```

## ▶️ How to Run

### Option 1: Static Version (Recommended)
1. Simply open `index.html` in any web browser
2. No installation or setup required
3. All data is stored in browser localStorage
4. Works completely offline after initial load

### Option 2: Full Backend Version
1. Install Node.js and MongoDB
2. Run `npm install` in the backend directory
3. Configure environment variables
4. Run `npm start` to start the server
5. Open frontend files in browser

## 🎯 User Stories Implementation

### User Story 1 – User Registration & Login
- Students and faculty can register with name, email, password, and role
- Secure login functionality with validation
- User data stored in localStorage (static version)

### User Story 2 – Course Management
- Faculty can create courses with title, description, and duration
- Students can view all available courses
- Courses display with optional YouTube video integration

### User Story 3 – Course Enrollment
- Students can enroll in courses
- Students can view their enrolled courses
- Faculty can see enrollment statistics

### User Story 4 – Assignment Submission
- Faculty can create assignments with due dates
- Students can submit assignments
- Faculty can view all submissions

### User Story 5 – Grading System
- Faculty can grade student assignments with scores and feedback
- Students can view their grades
- Overall performance tracking

## 🤝 Team Members

- [Team Member 1] - Full Stack Developer
- [Team Member 2] - Frontend Developer
- [Team Member 3] - Backend Developer

## 🌐 Deployment Links

### Hosted Version
- **Frontend**: [https://your-project.vercel.app](https://your-project.vercel.app)
- **Backend API**: [https://your-project-api.onrender.com](https://your-project-api.onrender.com)

### GitHub Repository
- [https://github.com/your-username/lms-project](https://github.com/your-username/lms-project)

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Bootstrap for UI components
- Flaticon for icons
- Freepik for images