# Screenshots

This directory should contain screenshots of the application for documentation purposes.

## Required Screenshots

1. `landing.png` - Landing page
2. `login.png` - Login/Registration page
3. `faculty.png` - Faculty dashboard
4. `student.png` - Student dashboard

## Instructions

Take screenshots of each page and save them with the names above for inclusion in the main README.md file.