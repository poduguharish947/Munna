const axios = require('axios');

// Base URL for the API
const BASE_URL = 'http://localhost:5000/api';

// Test the complete API workflow
async function testFullAPI() {
  try {
    console.log('Testing complete API workflow...\n');
    
    // Step 1: Login faculty
    console.log('1. Logging in as faculty...');
    const facultyLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'faculty@test.com',
      password: 'faculty123'
    });
    const facultyToken = facultyLogin.data.token;
    console.log('✅ Faculty logged in\n');
    
    // Step 2: Login student
    console.log('2. Logging in as student...');
    const studentLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'student@test.com',
      password: 'student123'
    });
    const studentToken = studentLogin.data.token;
    console.log('✅ Student logged in\n');
    
    // Step 3: Faculty creates a course
    console.log('3. Creating a course...');
    const courseData = {
      title: 'Test Course',
      description: 'This is a test course for API testing',
      duration: 4,
      video: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
    };
    
    const courseResponse = await axios.post(`${BASE_URL}/courses`, courseData, {
      headers: {
        'Authorization': `Bearer ${facultyToken}`
      }
    });
    const courseId = courseResponse.data._id;
    console.log('✅ Course created with ID:', courseId);
    console.log('Course title:', courseResponse.data.title);
    console.log();
    
    // Step 4: Get all courses
    console.log('4. Getting all courses...');
    const allCourses = await axios.get(`${BASE_URL}/courses`);
    console.log('✅ Retrieved', allCourses.data.length, 'courses\n');
    
    // Step 5: Student enrolls in the course
    console.log('5. Enrolling student in course...');
    const enrollmentResponse = await axios.post(`${BASE_URL}/enrollments`, {
      courseId: courseId
    }, {
      headers: {
        'Authorization': `Bearer ${studentToken}`
      }
    });
    console.log('✅ Student enrolled in course\n');
    
    // Step 6: Faculty creates an assignment
    console.log('6. Creating an assignment...');
    const assignmentData = {
      title: 'Test Assignment',
      description: 'This is a test assignment',
      dueDate: '2025-12-31',
      courseId: courseId
    };
    
    const assignmentResponse = await axios.post(`${BASE_URL}/assignments`, assignmentData, {
      headers: {
        'Authorization': `Bearer ${facultyToken}`
      }
    });
    const assignmentId = assignmentResponse.data._id;
    console.log('✅ Assignment created with ID:', assignmentId);
    console.log('Assignment title:', assignmentResponse.data.title);
    console.log();
    
    // Step 7: Student submits assignment
    console.log('7. Submitting assignment...');
    const submissionData = {
      assignmentId: assignmentId,
      submissionText: 'This is my test submission for the assignment.'
    };
    
    const submissionResponse = await axios.post(`${BASE_URL}/submissions`, submissionData, {
      headers: {
        'Authorization': `Bearer ${studentToken}`
      }
    });
    const submissionId = submissionResponse.data._id;
    console.log('✅ Assignment submitted with ID:', submissionId);
    console.log('Submission text:', submissionResponse.data.submissionText);
    console.log();
    
    // Step 8: Faculty grades the submission
    console.log('8. Grading submission...');
    const gradeData = {
      score: 85,
      feedback: 'Good work! Just a few minor improvements needed.'
    };
    
    const gradeResponse = await axios.put(`${BASE_URL}/submissions/${submissionId}/grade`, gradeData, {
      headers: {
        'Authorization': `Bearer ${facultyToken}`
      }
    });
    console.log('✅ Submission graded');
    console.log('Score:', gradeResponse.data.grade.score);
    console.log('Feedback:', gradeResponse.data.grade.feedback);
    console.log();
    
    // Step 9: Student views their grade
    console.log('9. Student viewing grades...');
    const studentSubmissions = await axios.get(`${BASE_URL}/submissions/my-submissions`, {
      headers: {
        'Authorization': `Bearer ${studentToken}`
      }
    });
    console.log('✅ Retrieved student submissions');
    console.log('Number of submissions:', studentSubmissions.data.length);
    if (studentSubmissions.data.length > 0) {
      const latestSubmission = studentSubmissions.data[0];
      console.log('Latest submission grade:', latestSubmission.grade ? latestSubmission.grade.score : 'Not graded');
    }
    console.log();
    
    console.log('🎉 Complete API workflow test passed! All features are working correctly.');
    console.log('\nSummary of tested features:');
    console.log('✅ User authentication (registration/login)');
    console.log('✅ Course management (create/view)');
    console.log('✅ Course enrollment');
    console.log('✅ Assignment creation');
    console.log('✅ Assignment submission');
    console.log('✅ Grading system');
    
  } catch (error) {
    console.error('❌ Error testing API:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

testFullAPI();