const express = require('express');
const router = express.Router();
const Submission = require('../models/Submission');
const Assignment = require('../models/Assignment');
const { auth } = require('../middleware/auth');

// Submit assignment (students only)
router.post('/', auth, async (req, res) => {
  try {
    const { assignmentId, submissionText } = req.body;
    
    // Check if assignment exists
    const assignment = await Assignment.findById(assignmentId);
    if (!assignment) {
      return res.status(404).json({ message: 'Assignment not found' });
    }
    
    // Check if already submitted
    const existingSubmission = await Submission.findOne({
      assignment: assignmentId,
      student: req.user.id
    });
    
    if (existingSubmission) {
      return res.status(400).json({ message: 'Assignment already submitted' });
    }
    
    // Create submission
    const submission = new Submission({
      assignment: assignmentId,
      student: req.user.id,
      submissionText
    });
    
    await submission.save();
    
    // Populate references
    await submission.populate('assignment', 'title');
    await submission.populate('student', 'name');
    
    res.status(201).json(submission);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get student's submissions (student only)
router.get('/my-submissions', auth, async (req, res) => {
  try {
    const submissions = await Submission.find({ student: req.user.id })
      .populate('assignment', 'title course')
      .populate('student', 'name');
    
    res.json(submissions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get submissions for an assignment (faculty only, for their assignments)
router.get('/assignment/:assignmentId', auth, async (req, res) => {
  try {
    // Check if assignment belongs to faculty
    const assignment = await Assignment.findById(req.params.assignmentId);
    if (!assignment) {
      return res.status(404).json({ message: 'Assignment not found' });
    }
    
    if (req.user.role === 'faculty' && assignment.faculty.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    const submissions = await Submission.find({ assignment: req.params.assignmentId })
      .populate('assignment', 'title')
      .populate('student', 'name email');
    
    res.json(submissions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Grade submission (faculty only, for their assignments)
router.put('/:id/grade', auth, async (req, res) => {
  try {
    const { score, feedback } = req.body;
    
    // Find submission
    const submission = await Submission.findById(req.params.id)
      .populate('assignment');
    
    if (!submission) {
      return res.status(404).json({ message: 'Submission not found' });
    }
    
    // Check if assignment belongs to faculty
    if (req.user.role === 'faculty' && 
        submission.assignment.faculty.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    // Update grade
    submission.grade = {
      score,
      feedback,
      gradedBy: req.user.id,
      gradedDate: new Date()
    };
    
    await submission.save();
    
    // Populate references
    await submission.populate('assignment', 'title');
    await submission.populate('student', 'name');
    await submission.populate('grade.gradedBy', 'name');
    
    res.json(submission);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;