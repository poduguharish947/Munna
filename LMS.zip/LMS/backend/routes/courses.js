const express = require('express');
const router = express.Router();
const Course = require('../models/Course');
const { auth, facultyAuth } = require('../middleware/auth');

// Create course (faculty only)
router.post('/', auth, facultyAuth, async (req, res) => {
  try {
    const { title, description, duration, video } = req.body;
    
    const course = new Course({
      title,
      description,
      duration,
      video,
      faculty: req.user.id
    });
    
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get all courses
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find().populate('faculty', 'name');
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get course by ID
router.get('/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate('faculty', 'name');
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update course (faculty only, owner only)
router.put('/:id', auth, facultyAuth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    // Check if faculty owns this course
    if (course.faculty.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    const { title, description, duration, video } = req.body;
    
    course.title = title || course.title;
    course.description = description || course.description;
    course.duration = duration || course.duration;
    course.video = video || course.video;
    
    await course.save();
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete course (faculty only, owner only)
router.delete('/:id', auth, facultyAuth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    // Check if faculty owns this course
    if (course.faculty.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    await course.remove();
    res.json({ message: 'Course removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;