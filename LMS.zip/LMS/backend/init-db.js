const axios = require('axios');

// Initialize the database with test data
async function initDatabase() {
  try {
    console.log('Initializing database with test data...\n');
    
    // Register faculty
    console.log('1. Registering faculty...');
    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        name: 'Dr. Smith',
        email: 'dr.smith@university.edu',
        password: 'faculty123',
        role: 'faculty'
      });
      console.log('✅ Faculty registered\n');
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.log('Faculty already exists\n');
      } else {
        throw error;
      }
    }
    
    // Register student
    console.log('2. Registering student...');
    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        name: 'John Student',
        email: 'john.student@university.edu',
        password: 'student123',
        role: 'student'
      });
      console.log('✅ Student registered\n');
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.log('Student already exists\n');
      } else {
        throw error;
      }
    }
    
    // Login faculty to get token
    console.log('3. Logging in as faculty...');
    const facultyLogin = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'dr.smith@university.edu',
      password: 'faculty123'
    });
    const facultyToken = facultyLogin.data.token;
    console.log('✅ Faculty logged in\n');
    
    // Create a course
    console.log('4. Creating a course...');
    const courseData = {
      title: 'Introduction to Computer Science',
      description: 'Learn the fundamentals of computer science including programming, algorithms, and data structures.',
      duration: 12,
      video: 'https://www.youtube.com/watch?v=6JQZ9gEYjAU'
    };
    
    const courseResponse = await axios.post('http://localhost:5000/api/courses', courseData, {
      headers: {
        'Authorization': `Bearer ${facultyToken}`
      }
    });
    const courseId = courseResponse.data._id;
    console.log('✅ Course created:', courseResponse.data.title);
    console.log('Course ID:', courseId);
    console.log();
    
    // Create an assignment
    console.log('5. Creating an assignment...');
    const assignmentData = {
      title: 'Programming Fundamentals Quiz',
      description: 'Complete the quiz on basic programming concepts covered in weeks 1-3.',
      dueDate: '2025-12-15',
      courseId: courseId
    };
    
    const assignmentResponse = await axios.post('http://localhost:5000/api/assignments', assignmentData, {
      headers: {
        'Authorization': `Bearer ${facultyToken}`
      }
    });
    const assignmentId = assignmentResponse.data._id;
    console.log('✅ Assignment created:', assignmentResponse.data.title);
    console.log('Assignment ID:', assignmentId);
    console.log();
    
    console.log('🎉 Database initialization complete!');
    console.log('\nTest accounts:');
    console.log('Faculty - Email: dr.smith@university.edu, Password: faculty123');
    console.log('Student - Email: john.student@university.edu, Password: student123');
    console.log('\nTest course:');
    console.log('Course: Introduction to Computer Science');
    console.log('Assignment: Programming Fundamentals Quiz');
    
  } catch (error) {
    console.error('❌ Error initializing database:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

initDatabase();