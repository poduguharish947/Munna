# EduLearn LMS Backend

This is the backend API for the EduLearn Learning Management System, built with Node.js, Express, and MongoDB.

## 🚀 Tech Stack

- **Node.js** - JavaScript runtime environment
- **Express.js** - Web application framework
- **MongoDB** - NoSQL database
- **Mongoose** - ODM for MongoDB
- **JSON Web Tokens (JWT)** - Authentication
- **Bcrypt.js** - Password hashing

## 📁 Project Structure

```
backend/
├── controllers/
├── middleware/
├── models/
├── routes/
├── .env
├── package.json
├── server.js
└── README.md
```

## 🛠️ Setup Instructions

1. **Install Dependencies**
   ```bash
   cd backend
   npm install
   ```

2. **Environment Variables**
   Create a `.env` file in the backend directory with the following variables:
   ```
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/lms
   JWT_SECRET=your_jwt_secret_key_here
   ```

3. **Run the Server**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## 📊 Database Schema

### User
- name (String)
- email (String, unique)
- password (String)
- role (String: 'student' or 'faculty')

### Course
- title (String)
- description (String)
- duration (Number)
- video (String, optional)
- faculty (ObjectId, ref: User)

### Enrollment
- student (ObjectId, ref: User)
- course (ObjectId, ref: Course)

### Assignment
- title (String)
- description (String)
- dueDate (Date)
- course (ObjectId, ref: Course)
- faculty (ObjectId, ref: User)

### Submission
- assignment (ObjectId, ref: Assignment)
- student (ObjectId, ref: User)
- submissionText (String)
- grade (Object)
  - score (Number)
  - feedback (String)
  - gradedBy (ObjectId, ref: User)
  - gradedDate (Date)

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile

### Courses
- `POST /api/courses` - Create a new course (faculty only)
- `GET /api/courses` - Get all courses
- `GET /api/courses/:id` - Get a specific course
- `PUT /api/courses/:id` - Update a course (faculty only)
- `DELETE /api/courses/:id` - Delete a course (faculty only)

### Enrollments
- `POST /api/enrollments` - Enroll in a course (student only)
- `GET /api/enrollments/my-enrollments` - Get student's enrollments (student only)
- `GET /api/enrollments/course/:courseId` - Get course enrollments (faculty only)

### Assignments
- `POST /api/assignments` - Create an assignment (faculty only)
- `GET /api/assignments/course/:courseId` - Get assignments for a course
- `GET /api/assignments/:id` - Get a specific assignment
- `PUT /api/assignments/:id` - Update an assignment (faculty only)
- `DELETE /api/assignments/:id` - Delete an assignment (faculty only)

### Submissions
- `POST /api/submissions` - Submit an assignment (student only)
- `GET /api/submissions/my-submissions` - Get student's submissions (student only)
- `GET /api/submissions/assignment/:assignmentId` - Get submissions for an assignment (faculty only)
- `PUT /api/submissions/:id/grade` - Grade a submission (faculty only)

## 🔐 Authentication

All protected routes require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a pull request

## 📄 License

This project is licensed under the MIT License.