const axios = require('axios');

// Test the API endpoints
async function testAPI() {
  try {
    console.log('Testing API endpoints...\n');
    
    // Test 1: Get all courses (should be empty)
    console.log('1. Testing GET /api/courses');
    const coursesResponse = await axios.get('http://localhost:5000/api/courses');
    console.log('Status:', coursesResponse.status);
    console.log('Data:', coursesResponse.data);
    console.log('✅ Courses endpoint working\n');
    
    // Test 2: Register a faculty member
    console.log('2. Testing POST /api/auth/register (faculty)');
    try {
      const facultyResponse = await axios.post('http://localhost:5000/api/auth/register', {
        name: 'Test Faculty',
        email: 'faculty@test.com',
        password: 'faculty123',
        role: 'faculty'
      });
      console.log('Status:', facultyResponse.status);
      console.log('Token received:', facultyResponse.data.token ? '✅' : '❌');
      var facultyToken = facultyResponse.data.token;
      console.log('✅ Faculty registration working\n');
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.log('User already exists, testing login instead...');
        // Login faculty
        const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
          email: 'faculty@test.com',
          password: 'faculty123'
        });
        console.log('Status:', loginResponse.status);
        console.log('Token received:', loginResponse.data.token ? '✅' : '❌');
        var facultyToken = loginResponse.data.token;
        console.log('✅ Faculty login working\n');
      } else {
        throw error;
      }
    }
    
    // Test 3: Register a student
    console.log('3. Testing POST /api/auth/register (student)');
    try {
      const studentResponse = await axios.post('http://localhost:5000/api/auth/register', {
        name: 'Test Student',
        email: 'student@test.com',
        password: 'student123',
        role: 'student'
      });
      console.log('Status:', studentResponse.status);
      console.log('Token received:', studentResponse.data.token ? '✅' : '❌');
      var studentToken = studentResponse.data.token;
      console.log('✅ Student registration working\n');
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.log('User already exists, testing login instead...');
        // Login student
        const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
          email: 'student@test.com',
          password: 'student123'
        });
        console.log('Status:', loginResponse.status);
        console.log('Token received:', loginResponse.data.token ? '✅' : '❌');
        var studentToken = loginResponse.data.token;
        console.log('✅ Student login working\n');
      } else {
        throw error;
      }
    }
    
    // Test 4: Login faculty (if not already done)
    if (!facultyToken) {
      console.log('4. Testing POST /api/auth/login (faculty)');
      const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
        email: 'faculty@test.com',
        password: 'faculty123'
      });
      console.log('Status:', loginResponse.status);
      console.log('Token received:', loginResponse.data.token ? '✅' : '❌');
      var facultyToken = loginResponse.data.token;
      console.log('✅ Faculty login working\n');
    }
    
    console.log('🎉 All API tests passed! The backend is working correctly.');
  } catch (error) {
    console.error('❌ Error testing API:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

testAPI();